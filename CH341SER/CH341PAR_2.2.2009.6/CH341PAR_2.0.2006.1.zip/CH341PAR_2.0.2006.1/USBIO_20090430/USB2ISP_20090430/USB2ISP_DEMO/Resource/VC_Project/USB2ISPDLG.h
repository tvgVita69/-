// USB2ISPDlg.h : header file
//

#if !defined(AFX_USB2ISPDLG_H__792438EF_8C82_4EA0_905B_30A7A46AE668__INCLUDED_)
#define AFX_USB2ISPDLG_H__792438EF_8C82_4EA0_905B_30A7A46AE668__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CUSB2ISPDlg dialog
class CUSB2ISPDlg : public CDialog
{
// Construction
public:

	ULONG mIndex;
	BOOL m_open;
	CUSB2ISPDlg(CWnd* pParent = NULL);	// standard constructor
	PUCHAR mStrtoVal(PUCHAR str,ULONG strlen);
	UCHAR mCharToBcd(UCHAR iChar);
	ULONG CUSB2ISPDlg::mStrToBcd(CString str);
	BOOL mClose();
    void enablebtn(BOOL bEnable);

// Dialog Data
	//{{AFX_DATA(CUSB2ISPDlg)
	enum { IDD = IDD_USB2ISP_DIALOG };
	CButton	m_ok;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUSB2ISPDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CUSB2ISPDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

//CUSB2ISPDlg * p_Dlg;
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_USB2ISPDLG_H__792438EF_8C82_4EA0_905B_30A7A46AE668__INCLUDED_)
