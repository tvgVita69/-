//*****************************************
//**  Copyright USBIO (C) S.ZK 2008.04   **
//**  Web:  http://www.usb-i2c-spi.com   **
//*****************************************
//**  LIB for USB interface chip USB2XXX **
//**  C, GCC                             **
//*****************************************
//
// USB总线接口芯片USB2XXX应用层接口库 V1.6
// USB2XXX-LIB  V1.0
// 运行环境: Linux
// support USB chip: USB2I2C,USB2SPI,USB2ISP
// USB  ->  I2C, SPI, EPP, MEM, GPIO (MASTER)
// USB <=> I2C:SCL/SDA
//     <=> SPI:SCK/MOSI/MISO/CS0-CS2
//     <=> EPP PARR
//     <=> MEM 

#ifndef		_USBIOX_DLL_H
#define		_USBIOX_DLL_H

#ifdef __cplusplus
extern "C" {
#endif

#define		mOFFSET( s, m )			( (Uunsigned long) & ( ( ( s * ) 0 ) -> m ) )	// 定义获取结构成员相对偏移地址的宏

#ifndef		max
#define		max( a, b )				( ( ( a ) > ( b ) ) ? ( a ) : ( b ) )	// 较大值
#endif

#ifndef		min
#define		min( a, b )				( ( ( a ) < ( b ) ) ? ( a ) : ( b ) )	// 较小值
#endif

#ifdef		ExAllocatePool
#undef		ExAllocatePool						// 删除带TAG的内存分配
#endif

#define FALSE 0
#define TRUE 1

#define		mUSBI0_MAX_NUMBER		16			// 最多同时连接的USB2XXX设备数
#define		mMAX_BUFFER_LENGTH		0x1000		// 数据缓冲区最大长度4096
#define		mDEFAULT_BUFFER_LEN		0x0400		// 数据缓冲区默认长度1024
#define		mUSBI0_PACKET_LENGTH 32
#define 	mUSBI0B_PACKET_LENGTH 64

// USB2XXX端点地址
#define		mUSBI0_ENDP_INTER_UP		0x81		// USB2XXX的中断数据上传端点的地址
#define		mUSBI0_ENDP_INTER_DOWN	0x01		// USB2XXX的中断数据下传端点的地址
#define		mUSBI0_ENDP_DATA_UP		0x82		// USB2XXX的数据块上传端点的地址
#define		mUSBI0_ENDP_DATA_DOWN	0x02		// USB2XXX的数据块下传端点的地址

// 设备层接口提供的管道操作命令
#define		mPipeDeviceCtrl			0x00000004	// USB2XXX的综合控制管道
#define		mPipeInterUp				0x00000005	// USB2XXX的中断数据上传管道
#define		mPipeDataUp				0x00000006	// USB2XXX的数据块上传管道
#define		mPipeDataDown			0x00000007	// USB2XXX的数据块下传管道

// 应用层接口的功能代码
#define		mFuncNoOperation			0x00000000	// 无操作
#define		mFuncGetVersion			0x00000001	// 获取驱动程序版本号
#define		mFuncGetConfig			0x00000002	// 获取USB设备配置描述符
#define		mFuncSetTimeout			0x00000009	// 设置USB通讯超时
#define		mFuncSetExclusive			0x0000000b	// 设置独占使用
#define		mFuncResetDevice			0x0000000c	// 复位USB设备
#define		mFuncResetPipe			0x0000000d	// 复位USB管道
#define		mFuncAbortPipe			0x0000000e	// 取消USB管道的数据请求

// USB2XXX并口专用的功能代码
#define		mFuncSetParaMode			0x0000000f	// 设置并口模式
#define		mFuncReadData0			0x00000010	// 从并口读取数据块0
#define		mFuncReadData1			0x00000011	// 从并口读取数据块1
#define		mFuncWriteData0			0x00000012	// 向并口写入数据块0
#define		mFuncWriteData1			0x00000013	// 向并口写入数据块1
#define		mFuncWriteRead			0x00000014	// 先输出再输入
#define		mFuncBufferMode			0x00000020	// 设定缓冲上传模式及查询缓冲区中的数据长度
#define		mFuncBufferModeDn		0x00000021	// 设定缓冲下传模式及查询缓冲区中的数据长度


// USB设备标准请求代码
#define		mUSB_CLR_FEATURE		0x01
#define		mUSB_SET_FEATURE		0x03
#define		mUSB_GET_STATUS		0x00
#define		mUSB_SET_ADDRESS		0x05
#define		mUSB_GET_DESCR		0x06
#define		mUSB_SET_DESCR			0x07
#define		mUSB_GET_CONFIG		0x08
#define		mUSB_SET_CONFIG		0x09
#define		mUSB_GET_INTERF		0x0a
#define		mUSB_SET_INTERF		0x0b
#define		mUSB_SYNC_FRAME		0x0c

// USB2XXX控制传输的厂商专用请求类型
#define		mUSBI0_VENDOR_READ		0xC0		// 通过控制传输实现的USB2XXX厂商专用读操作
#define		mUSBI0_VENDOR_WRITE		0x40		// 通过控制传输实现的USB2XXX厂商专用写操作

// USB2XXX控制传输的厂商专用请求代码
#define		mUSBI0_PARA_INIT			0xB1		// 初始化并口
#define		mUSBI0_I2C_STATUS			0x52		// 获取I2C接口的状态
#define		mUSBI0_I2C_COMMAND		0x53		// 发出I2C接口的命令

// USB2XXX并口操作命令代码
#define		mUSBI0_PARA_CMD_R0		0xAC		// 从并口读数据0,次字节为长度
#define		mUSBI0_PARA_CMD_R1		0xAD		// 从并口读数据1,次字节为长度
#define		mUSBI0_PARA_CMD_W0		0xA6		// 向并口写数据0,从次字节开始为数据流
#define		mUSBI0_PARA_CMD_W1		0xA7		// 向并口写数据1,从次字节开始为数据流
#define		mUSBI0_PARA_CMD_STS		0xA0		// 获取并口状态

// USB2XXX并口操作命令代码

#define		mUSBIOA_CMD_SET_OUTPUT	0xA1		// 设置并口输出
#define		mUSBIOA_CMD_IO_ADDR		0xA2		// MEM带地址读写/输入输出,从次字节开始为命令流
#define		mUSBIOA_CMD_PRINT_OUT	0xA3		// PRINT兼容打印方式输出,从次字节开始为数据流
#define		mUSBIOB_CMD_PWM_OUT		0xA4		// PWM数据输出的命令包,从次字节开始为数据流
#define		mUSBIOB_CMD_SHORT_PKT	0xA5		// 短包,次字节是该命令包的真正长度,再次字节及之后的字节是原命令包
#define		mUSBIOA_CMD_SPI_STREAM	0xA8		// SPI接口的命令包,从次字节开始为数据流
#define		mUSBIOA_CMD_SIO_STREAM	0xA9		// SIO接口的命令包,从次字节开始为数据流
#define		mUSBIOA_CMD_I2C_STREAM	0xAA		// I2C接口的命令包,从次字节开始为I2C命令流
#define		mUSBIOA_CMD_UIO_STREAM	0xAB		// UIO接口的命令包,从次字节开始为命令流
#define		mUSBIOB_CMD_PIO_STREAM	0xAE		// PIO接口的命令包,从次字节开始为数据流

// USB2XXX控制传输的厂商专用请求代码

#define		mUSBIOA_BUF_CLEAR			0xB2		// 清除未完成的数据
#define		mUSBIOA_I2C_CMD_X			0x54		// 发出I2C接口的命令,立即执行
#define		mUSBIOA_DELAY_MS			0x5E		// 以亳秒为单位延时指定时间
#define		mUSBIOA_GET_VER			0x5F		// 获取芯片版本

#define		mUSBI0_EPP_IO_MAX		( mUSBI0_PACKET_LENGTH - 1 )	// USB2XXX在EPP/MEM方式下单次读写数据块的最大长度
#define		mUSBIOA_EPP_IO_MAX		0xFF		// USB2XXX(A)在EPP/MEM方式下单次读写数据块的最大长度

#define		mUSBIOA_CMD_IO_ADDR_W	0x00		// MEM带地址读写/输入输出的命令流:写数据,位6-位0为地址,下一个字节为待写数据
#define		mUSBIOA_CMD_IO_ADDR_R	0x80		// MEM带地址读写/输入输出的命令流:读数据,位6-位0为地址,读出数据一起返回

#define		mUSBIOA_CMD_I2C_STM_STA	0x74		// I2C接口的命令流:产生起始位
#define		mUSBIOA_CMD_I2C_STM_STO	0x75		// I2C接口的命令流:产生停止位
#define		mUSBIOA_CMD_I2C_STM_OUT	0x80		// I2C接口的命令流:输出数据,位5-位0为长度,后续字节为数据,0长度则只发送一个字节并返回应答
#define		mUSBIOA_CMD_I2C_STM_IN	0xC0		// I2C接口的命令流:输入数据,位5-位0为长度,0长度则只接收一个字节并发送无应答
#define		mUSBIOA_CMD_I2C_STM_MAX	( min( 0x3F, mUSBI0_PACKET_LENGTH ) )	// I2C接口的命令流单个命令输入输出数据的最大长度
#define		mUSBIOA_CMD_I2C_STM_SET	0x60		// I2C接口的命令流:设置参数,位2=SPI的I/O数(0=单入单出,1=双入双出),位1位0=I2C速度(00=低速,01=标准,10=快速,11=高速)
#define		mUSBIOA_CMD_I2C_STM_US	0x40		// I2C接口的命令流:以微秒为单位延时,位3-位0为延时值
#define		mUSBIOA_CMD_I2C_STM_MS	0x50		// I2C接口的命令流:以亳秒为单位延时,位3-位0为延时值
#define		mUSBIOA_CMD_I2C_STM_DLY	0x0F		// I2C接口的命令流单个命令延时的最大值
#define		mUSBIOA_CMD_I2C_STM_END	0x00		// I2C接口的命令流:命令包提前结束

#define		mUSBIOA_CMD_UIO_STM_IN	0x00		// UIO接口的命令流:输入数据D7-D0
#define		mUSBIOA_CMD_UIO_STM_DIR	0x40		// UIO接口的命令流:设定I/O方向D5-D0,位5-位0为方向数据
#define		mUSBIOA_CMD_UIO_STM_OUT	0x80		// UIO接口的命令流:输出数据D5-D0,位5-位0为数据
#define		mUSBIOA_CMD_UIO_STM_US	0xC0		// UIO接口的命令流:以微秒为单位延时,位5-位0为延时值
#define		mUSBIOA_CMD_UIO_STM_END	0x20		// UIO接口的命令流:命令包提前结束


// USB2XXX并口工作模式
#define		mUSBI0_PARA_MODE_EPP		0x00		// USB2XXX并口工作模式为EPP方式
#define		mUSBI0_PARA_MODE_EPP17	0x00		// USB2XXX(A)并口工作模式为EPP方式V1.7
#define		mUSBI0_PARA_MODE_EPP19	0x01		// USB2XXX(A)并口工作模式为EPP方式V1.9
#define		mUSBI0_PARA_MODE_MEM		0x02		// USB2XXX并口工作模式为MEM方式
#define		mUSBI0_PARA_MODE_ECP		0x03		// USB2XXX(A)并口工作模式为ECP方式


// I/O方向设置位定义,直接输入的状态信号的位定义,直接输出的位数据定义
#define		mStateBitERR			0x00000100	// 只读可写,ERR#引脚输入状态,1:高电平,0:低电平
#define		mStateBitPEMP			0x00000200	// 只读可写,PEMP引脚输入状态,1:高电平,0:低电平
#define		mStateBitINT			0x00000400	// 只读可写,INT#引脚输入状态,1:高电平,0:低电平
#define		mStateBitSLCT			0x00000800	// 只读可写,SLCT引脚输入状态,1:高电平,0:低电平
#define		mStateBitWAIT			0x00002000	// 只读可写,WAIT#引脚输入状态,1:高电平,0:低电平
#define		mStateBitDATAS		0x00004000	// 只写可读,DATAS#/READ#引脚输入状态,1:高电平,0:低电平
#define		mStateBitADDRS		0x00008000	// 只写可读,ADDRS#/ADDR/ALE引脚输入状态,1:高电平,0:低电平
#define		mStateBitRESET		0x00010000	// 只写,RESET#引脚输入状态,1:高电平,0:低电平
#define		mStateBitWRITE		0x00020000	// 只写,WRITE#引脚输入状态,1:高电平,0:低电平
#define		mStateBitSCL			0x00400000	// 只读,SCL引脚输入状态,1:高电平,0:低电平
#define		mStateBitSDA			0x00800000	// 只读,SDA引脚输入状态,1:高电平,0:低电平


#define		MAX_DEVICE_PATH_SIZE		128			// 设备名称的最大字符数
#define		MAX_DEVICE_ID_SIZE		64			// 设备ID的最大字符数

typedef	enum	_EEPROM_TYPE {					// EEPROM型号
	ID_24C01,
	ID_24C02,
	ID_24C04,
	ID_24C08,
	ID_24C16,
	ID_24C32,
	ID_24C64,
	ID_24C128,
	ID_24C256,
	ID_24C512,
	ID_24C1024,
	ID_24C2048,
	ID_24C4096
} EEPROM_TYPE;




#ifdef __cplusplus
}
#endif

#endif		// _USBIOX_DLL_H
