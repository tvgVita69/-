#include <stdio.h>
#include <string.h>
#include </usr/include/usb.h>
#include "USBIOX.h"

////////////////////////////////////////////////////////////////////

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <pthread.h>
#include <errno.h>
#include <sys/select.h>

#define LOG(fmt, args...) printf("TV_SDIO: line %d:in fun %s:" fmt "", __LINE__, __FUNCTION__,  ## args)

#define CMD_LEN         16
static int		wtloop = 0;


///////////////////////////////////////////////////////////////////
#define vid_old 	0x4348
#define vid_new 	0x1a86
#define pid 		0x5512

//调试
#define debug 1
#undef dbg
#define dbg(format, arg...) do { if(debug)printf(format "\n" , ## arg); } while (0)

#define VERSION "0.1"
//////////////////////////////////////////////////////////////////////////////////////
unsigned char gucReceDataBuffer[204800];
unsigned int CurDataLen,CurDataAdr;

#define KillTimer(t) do{}while(0)

#define TV_STREAM_PATH "/dev/tv_stream"
#define TV_STREAM_IOCTL_WR           100
#define TV_STREAM_IOCTL_WR_POLLING           101
#define TV_STREAM_IOCTL_WR_Q     102
#define TV_STREAM_IOCTL_SDIO_RESET                201


#define DATA_PORT_REG                                     0x99

#define INT_IDENTIFICATION_REG                      0x01
#define FUN1_READ_DATA_READY_MASK             (1<<0)
#define INT_FROM_CHIP_TO_HOST_MASK           (1<<1)


#define READ_TRANSFER_COUT_REG_L                0x02
#define READ_TRANSFER_COUT_REG_M               0x03
#define READ_TRANSFER_COUT_REG_H               0x04

#define WRITE_TRANSFER_COUT_REG_L              0x05
#define WRITE_TRANSFER_COUT_REG_M             0x06
#define WRITE_TRANSFER_COUT_REG_H             0x07

#define SDIO_R                     0
#define SDIO_W                    1	

struct spibus_ioctl_write_read_param
{
	char *txbuf;
	int txlen;
	char *rxbuf;
	int  rxlen;
};
typedef struct spibus_ioctl_write_read_param spibus_wr_buf;

#ifndef bool
#define bool int
#endif
#define false (0)
#define true  (1)

// Mutex type
typedef pthread_mutex_t Mutex;//!< linux mutex definition

Mutex sdio_mutex;



/////////////////////////////////////////////////////////////////////////////////////

struct sUSBIO_context
{
	struct usb_device *dev; //设备指针
	int write_timeout; //写超时
	int read_timeout; //读超时
	int out_ep; //下传端点
	int in_ep; //上传端点
	int index;	 //设备号	
	unsigned char	USBIO_ver_ic;	//USB2XXX的芯片版本号
	unsigned char	USBIO_stream_mode;	// USB2XXX的串口流模式
};

struct sUSBIO_context sUSBIO[mUSBI0_MAX_NUMBER]; //结构体数组
usb_dev_handle *usb_dev[mUSBI0_MAX_NUMBER];



int OSW_MutexCreate (Mutex * mutex )
{
     if(NULL == mutex){
	     LOG("param error\n");
	     return -1;
     }
     // init mutex
     int rc = pthread_mutex_init ( mutex, NULL );
     if (rc != 0){
	     LOG("mutex init error\n");	     
	     return -1;
     }

     return rc;
}

/*!  release a mutex
  \param[in] mutex: pointer to a mutex
  \returnstatus of the operation.
*/
int OSW_MutexDelete ( Mutex * mutex )
{

	if(NULL == mutex){
		LOG("Param error\n");
		return -1;
	}
     // destroy mutex
     int rc = pthread_mutex_destroy ( mutex );
     if (rc != 0){
	     LOG("mutex destroy error\n");
	     return -1;
     }

     return rc;
}

/*!  unlock a mutex
  \param[in] mutex: pointer to a mutex
  \returnstatus of the operation.
*/
int OSW_MutexPut ( Mutex * mutex )
{
	if(NULL == mutex){
		LOG("Param error\n");
		return -1;
	}

     // unlock mutex
     int rc = pthread_mutex_unlock ( mutex );
     if (rc != 0){
	     LOG("unlock mutex error\n");
	     return -1;
     }
     return rc;
}

/*!  lock a mutex
  \param[in] mutex: pointer to a mutex
  \returnstatus of the operation.
*/
int OSW_MutexGet ( Mutex * mutex )
{
	if(NULL == mutex){
		LOG("Param error\n");
		return -1;
	}

     // get mutex
     int rc = pthread_mutex_lock ( mutex );
     if (rc != 0){
	     LOG("lock mutex error\n");
	     return -1;
     }
     return rc;
}


void printbuf( char  *pbuf, int size)
{

	char *p = pbuf;
	if(NULL == pbuf && size <0)
	{
		LOG("param is error\n");
		return ;
	}
	printf("The buf :");
	while(size--)
	{
		printf("0x%x ", *p);
		p++;
	}
	printf("\n");
}


// --------------------------------------------------------------------
// SDIO SPI mode initialize
// --------------------------------------------------------------------
//

///////////////////////////////////////////////////////////////////////////////////////
//			G(x) = x7 + x3 + 1    1000 1001	0x89
//          M(x) = (first bit)xn +��second bit)xn-1 + ...+(last bit)x0
//          CRC[6...0] = Remainder{(M(x) * x7)  / G(x)]
///////////////////////////////////////////////////////////////////////////////////////
unsigned char CRC7_Handle(unsigned char *message, unsigned int CRC7_Num)
{ 
	unsigned char i; 
	unsigned int crc=0; 

	while(CRC7_Num--!=0) 
	{ 
		for(i=0x80; i!=0; i/=2) 
		{ 
			if((crc&0x40)!=0) 
			{
				crc*=2; 
				crc^=0x09;
			}    
			else 
			{
				crc*=2; 
			}
			if((*message&i)!=0) 
			{
				crc^=0x09;
			}
		} 
		message++; 
	} 
	crc = crc & 0x7f;
	crc = crc << 1;
	crc = crc | 0x01;
	return(crc); 
} 


int tvstream_fd = -1;

// if(	USBIO_StreamSPI4( 0, 0x80, 16, buffer))
bool USBIO_StreamSPI4( char nouse, char nouse1, int len, char *buffer)
{
  
	//LOG("enter len %d\n", len);
	int r = 0;
	if(len <= 0 || NULL == buffer)
	{
		LOG("param is error len = %d\n", len);
		return false;
	}
  
	spibus_wr_buf wr_buf = {
		.txbuf = buffer,
		.txlen = len,
		.rxbuf = buffer,
		.rxlen = len,
	    
	};


	if(tvstream_fd < 0) tvstream_fd = open(TV_STREAM_PATH, O_RDWR);
	if (tvstream_fd<0)
	{
		LOG("Open tv_stream error, fd=%d\n",tvstream_fd);
		return false;

	}
	else 
		printf("open tvstream_fd ok  = %d\n ",tvstream_fd );

	
	// ��ʱ���ε� TV_STREAM_IOCTL_WR_Q      2008.08.13
	
	/*
	if((r = ioctl(tvstream_fd, TV_STREAM_IOCTL_WR_Q, &wr_buf)) < 0){
		LOG("Ioctl fail 0x%x\n", r);
		return false;
	}
	*/
	
	//printbuf(buffer, len);
	//USB2XXX_stream_spi4(nouse, nouse1, len, buffer);
	return true;
//	return USB2XXX_stream_spix( 0, 0x80, 16, buffer, (unsigned char *)1);
	
}


unsigned char SDIO_init(void)
{
#ifdef	SDIO_READ_WRITE_API
 #define SDIO_INIT    200
	int r = 0;
	if(tvstream_fd < 0) {
		tvstream_fd = open(TV_STREAM_PATH, O_RDWR);
		if(tvstream_fd < 0) {
			LOG("open %s fail\n", TV_STREAM_PATH);
			return -1;
		}
	}
	if(r = ioctl(tvstream_fd, SDIO_INIT)) {
		LOG("init fail %d\n", r);
		return -1;
	}
	return 0;
#else


//////////////////////////////////////////////////////////////////////

/*
#define SDIO_INIT    200
	int r = 0;
//	if(tvstream_fd < 0) {
		tvstream_fd = open(TV_STREAM_PATH, O_RDWR);
		if(tvstream_fd < 0) {
			LOG("open %s fail\n", TV_STREAM_PATH);
			return -1;
		}
	//}

	*/
	
////////////////////////////////////////////////////////////////////////


	unsigned char buffer[16];
	int i, j;
	unsigned char tempChar;

	int		k;
	
	if(OSW_MutexCreate(&sdio_mutex)){
		LOG("Create mutex error\n");
		return -1;
	}
		
	// Open SPI to USB device
//	if(!USBIO_OpenDevice(0)){
/*
	if(!USB2XXX_open(0)){

		return 1;
		printf("USB2XXX_open failed \n");
	}

*/
	// Set SPI to USB chip

	//if( USBIO_SetStream(0, 0x81) == false)
	if( USB2XXX_set_stream(0, 0x81) == false)
	{
		return 2;
	}

	
	for (k = 0; k < 3; k++)
	{
		// send SDIO command 0
		buffer[0] = 0x40;
		buffer[1] = 0x00;
		buffer[2] = 0x00;
		buffer[3] = 0x00;
		buffer[4] = 0x00;
		buffer[5] = 0x95;
		//buffer[5] = CRC7_Handle(&buffer[0], 5);   // PC 
		for(i=6; i<16; i++)
		{
			buffer[i] = 0xFF;
		}

		printf("\nBefore USB2XXX_stream_spi4 buffer[0-15]:\n");
		for(i=0;i<16;i++)
	printf(" buffer[%d] = %X",i,buffer[i]);
		printf("\n");
	
	//	if(	USBIO_StreamSPI4( 0, 0x80, 0x16, buffer))			
//	if(USB2XXX_stream_spix( 0, 0x80, 16, buffer, (unsigned char *)1))
/////////// //////////////////////////////////////////////////////////////////////edit
	unsigned char kk;
		if (kk = USB2XXX_stream_spi4(0, 0x80, 16, buffer))

/////////////////////////////////////////////////////////////////////////////////over
			{
			
			printf("After USB2XXX_stream_spi4 buffer[0-15]:\n");
			printf("USB2XXX_stream_spi4(0, 0x80, 16, buffer) = %d \n",kk);
			for(i=0; i<16; i++)			// check response
			{
#if 1		
				printf("buffer[%d] = %X  ",i,buffer[i]);
				

				if(buffer[i] == 0x01)
				{
					
					goto outof_cmd0;
				}
				
#else
				if (0x01 == buffer[i])
				{
					while(1)
					{
						printf("okokok\n");
						printf("wtloop:%d\n", wtloop);
						sleep(1);
					}

					break;
				}
#endif
			}
			if(i == 16)
			{
				return 3;
			}

			
		}


		
	}

outof_cmd0:

	// send SDIO command 5
	buffer[0] = 0x45;
	buffer[1] = 0x00;
	buffer[2] = 0x00;
	buffer[3] = 0x00;
	buffer[4] = 0x00;
	buffer[5] = 0x37;
	for(i=6; i<16; i++)
	{
		buffer[i] = 0xFF;
	}
//	if(	USBIO_StreamSPI4( 0, 0x80, 16, buffer))
	if (USB2XXX_stream_spi4(0, 0x80, 16, buffer))
	{
		for(i=0; i<16; i++)
		{
#if 0
			if(buffer[i] == 0x01)
				break;
#else
			if (0x01 == buffer[i])
			{
#if 0
				while(1)
				{
					printf("okokok\n");
					printf("wtloop:%d\n", wtloop);
					sleep(1);
				}
#endif
				break;
			}
#endif
		}
		if(i == 16)
		{
			return 4;
		}

		// check 01 10 FF 80 00 response with OCR
		if(buffer[i+1] != 0x10 || buffer[i+2] != 0xFF || buffer[i+3] != 0x80 || buffer[i+4] != 0x00)
		{
			return 0x05;
		}
	}

	LOG("Send command 5 with OCR\n");
	// send command 5 with OCR
	usleep(100 * 1000);
	for(j=0; j<16; j++)
	{
		buffer[0] = 0x45;
		buffer[1] = 0x00;
		buffer[2] = 0xFF;
		buffer[3] = 0x80;
		buffer[4] = 0x00;
		buffer[5] = 0x37;
		for(i=6; i<16; i++)
		{
			buffer[i] = 0xFF;
		}
		//if(	USBIO_StreamSPI4( 0, 0x80, 16, buffer))

		if (USB2XXX_stream_spi4(0, 0x80, 16, buffer))

		{
			for(i=0; i<16; i++)
			{
				if(buffer[i] != 0xFF)
					break;
			}
			if(i == 16)
			{
				return 0x06;
			}

			// check card ready
			if((buffer[i+1] & 0x80) == 0x80)
			{
				goto NEXT;
			}
		}
	}
	if(j == 16)
	{
		return 0x07;
	}
 NEXT:
#if 0
	{
		char buf[0x13] = {0};
		if(!Send_CMD53(0, 0, 0, buf, sizeof(buf) / sizeof(buf[0]))){
			LOG("Send cmd53 fail in sdio init\n");			
		}else{
			LOG("Read fun0 sdio\n\n\n");
			printbuf(buf, sizeof(buf) / sizeof(buf[0]));
			LOG("Read fun0 sdio\n\n\n");
		}
	}
#endif

	// get CCCRX
#if 1
//	if(Send_CMD52(0, 0, 0, &tempChar) )

LOG("ready to Send cmd52 \n");

#else
        if(Send_CMD53(0, 0, 0, &tempChar, 1) )
#endif
	//{
		if(tempChar != 0x12)
		{
			return 0x08;
		}
	
//	}
	else
	{
		return 9;
	}

	// set IO Enable

/*
	if(Send_CMD53(0, 0, 0x02, &tempChar, 1) ){
		LOG("read 0x%x\n", tempChar);
	}else{
		LOG("read fail\n");
	}

	tempChar = 0x02;
#if 1
	if(!Send_CMD52(1, 0, 0x02, &tempChar))
#else
        if(!Send_CMD53(1, 0, 0x02, &tempChar, 1) )
#endif
	{
		LOG("Set IO Enable fail\n");
		return 0x0A;
	}else{
		LOG("Set IO Enable success\n");
		if(Send_CMD53(0, 0, 0x02, &tempChar, 1) ){
			LOG("read 0x%x\n", tempChar);
		}else{
			LOG("read fail\n");
		}
	}
	


	for(i=0; i<16; i++)
	{
		if(!Send_CMD52(0, 0, 0x03, &tempChar))
		{
			return 0x0B;
		}
		else
		{
			if((tempChar&0x02) == 0x02)
				break;
		}
	}

	if(i == 16)
	{
		return 0x0C;
	}

	*/
#if 0
	{
		char buf[0x13] = {0};
		int i = 0;
		/* for(i = 0; i < 2; i++){ */
/* 			buf[i] = 2 * i; */
/* 		} */
		buf[0] = 0x5;
		buf[1] = 0x1;
		buf[2] = 0x24;
		if(!Send_CMD53(1, 0, 0x10, buf, 2)){
			LOG("Send cmd53 fail in sdio init\n");			
		}


		buf[0] = 0x44;
		buf[1] = 0x44;
		buf[2] = 0x44;
		
		if(!Send_CMD53(0, 0, 0x10, buf, 2)){
			LOG("Send cmd53 fail in sdio init\n");			
		}else{
			LOG("Read fun1 sdio\n\n\n");
			printbuf(buf, 3);
			LOG("Read fun1 sdio\n\n\n");
		}
#if 0
		int i = 0;
		for(i = 0; i < sizeof(buf) / sizeof(buf[0]); i++){
			buf[i] = i;
		}
		
		if(!Send_CMD53(1, 0, 0, buf, sizeof(buf) / sizeof(buf[0]))){
			LOG("Send cmd53 fail in sdio init\n");			
		}else{
			for(i = 0; i < sizeof(buf) / sizeof(buf[0]); i++){
				buf[i] = 0x44;
			}
			LOG("write fun0 sdio success\n\n\n");
			if(!Send_CMD53(0, 0, 0, buf, sizeof(buf) / sizeof(buf[0]))){
				LOG("Send cmd53 fail in sdio init\n");			
			}else{
				LOG("Read fun0 sdio after write\n\n\n");
				printbuf(buf, sizeof(buf) / sizeof(buf[0]));
				LOG("Read fun0 sdio\n\n\n");
			}
			
		}
#endif
	}
#endif
	return 0;

#endif
}





void select_test( usb_dev_handle *USB2XXX_dev )
{
	unsigned char	inputr;
	unsigned char a;
	unsigned char read_buffer[256]="";
	unsigned char write_buffer[256]="";
	unsigned char i;
	printf("--------------------------------------------------------\
	      \n    USB2XXX: USB TO ISP LIB TEST PROGRAM  v%s  (GPL)		\
	      \n            <C> Enci Liang  @  usb-i2c-spi@hotmail.com	\
	      \n            Welcom to visit http://www.usb-i2c-spi.com  \
	      \n                          LastBuild: %s,%s\
	      \n--------------------------------------------------------\n", VERSION, __TIME__, __DATE__);
	do{
		printf("Please select test function...   \n");
		printf("1- USB2XXX_read_eeprom\n");
		printf("2- USB2XXX_write_eeprom\n");	
		printf("3- USB2XXX_spi4\n");
		printf("4- USB2XXX_open\n");
		printf("5- USB2XXX_close\n");
		printf("7- USB2XXX_Init &Deinit Test\n");
		printf("6- exit\n");
	again:	
		inputr = getchar( );
		if( inputr == 10) goto again;	
		switch( inputr )
		{
			case '1':
				USB2XXX_read_eeprom( 0, 3, 0, 0x20, read_buffer);
					for(i=0; i<0x20; i++)
					{
						printf("read_buffer[%d]=%d\n",i,read_buffer[i]);
					}	
					break;
				case '2':
					for( i=0; i<0x20; i++)
					{
						write_buffer[ i ] = 0x55;
					}
					USB2XXX_write_eeprom( 0, 3, 0, 0x20, write_buffer);
					break;
				case '3':
					for( i=0; i<0x10; i++)
					{
						write_buffer[ i ] = 0xAA;
					}
					USB2XXX_stream_spi4( 0, 0x80, 0x10, write_buffer );
					break;
				case '4':

					USB2XXX_open(USB2XXX_dev);
					
					
					break;
				case '5':
					break;

				case '7':                  // Init Test
					
				
					for (i = 0; i < 1; i++)
					{

					sleep(1);
					
					int val;
				wtloop = i;
		
					//sdio_reset();

				val = SDIO_init();
				printf("\n####: val = %d \n  ", val);
				

				if (0 == val)
					{
				while(1)
						{
				printf("wt: Init && Deinit OK!\n");
				sleep(1);
						}
					}
		//	 USB2XXX_deinit();
						}


					
					break;
				case '6':
					USB2XXX_close( USB2XXX_dev );
					exit(1);
					break;
		}

	}while( 1 );
}   



int main(int argc, char *argv[])
{
	usb_dev_handle *USB2XXX_dev;
	if( !USB2XXX_init( ) )printf("Not find USB2XXX device!\n");
	USB2XXX_dev = USB2XXX_open(0);
//	printf("USB2XXX_dev = %d\n",USB2XXX_dev);
	select_test( USB2XXX_dev );
}


