//****************************************
//**  C, VC6.0                          **
//****************************************
//
// USB2SPI ����


#include	<windows.h>
#include	<stdlib.h>
#include	<stdio.h>
#include	<conio.h>
#include	<winioctl.h>
#include	<math.h>

#include	"USBIOX.H"				// USB2SPI�Ķ�̬���ӿ�

static char line[250];

unsigned char write_2512_reg(reg_addr, reg_data);
unsigned char read_2512_reg(reg_addr, rd_num, reg_buffer);
unsigned char set_sclk_freq(sclk);

//�������
void main ( )
{
	//unsigned char	wr_buf[256], rd_buf[256];
	unsigned char	spi_flag, work_mode, exit_flag, reg_addr, rd_num;
	unsigned int	reg_data, i;
	unsigned int	reg_buffer[128];

	printf( "\nUSB2SPI Data Test Program V1.0 \n" );

// ��Ҫʹ��DLL����Ҫ�ȼ���
	printf( "Load DLL: USBIOX.DLL ......\n" );
	if ( LoadLibrary( "USBIOX.DLL" ) == NULL ) return;  // ����DLLʧ��,����δ��װ��ϵͳ��

	printf( "USBIO_OpenDevice: 0# \n\n" );
	if ( USBIO_OpenDevice( 0 ) == INVALID_HANDLE_VALUE ) return;  /* ʹ��֮ǰ������豸 */

	USBIO_SetStream(0, 0x80);
	exit_flag = 0;
	
	while (1)
	{
		printf("please enter work mode(r or w):");
		fgets(line, sizeof(line), stdin);
        sscanf(line, "%c", &work_mode);
        
        switch (work_mode)
        {
        	case 'w':
				printf("please enter register address and write number:");
				fgets(line, sizeof(line), stdin);
				sscanf(line, "%x %x", &reg_addr, &reg_data);
				spi_flag = write_2512_reg(reg_addr, reg_data);

				if (spi_flag == 1)
				{
					printf("write register success!\n\n");
				}
				else
				{
					printf("write register fail!\n\n");
				}
        		break;
        		
        	case 'r':
        		printf("please enter start address and read number:");
				fgets(line, sizeof(line), stdin);
				sscanf(line, "%x %d", &reg_addr, &rd_num);

				spi_flag = read_2512_reg(reg_addr, rd_num, reg_buffer);

				if (spi_flag == 1)
				{
					printf("register start address is %04x:", reg_addr);

					for (i = 0; i < rd_num; i++)
					{
						if (i%8 == 0)
						{
							printf("\n");
						}
						printf("%04x, ", reg_buffer[i]);
					}

					printf("\n\n");
				}
				else
				{
					printf("read register fail!\n\n");
				}
        		break;
        		
        	case 'e':
        		exit_flag = 1;
        		break;
        		
        	default:
        		printf("error intput!\n\n");
				exit_flag = 0;
        }
        
        if (exit_flag == 1)
        {
        	printf( "\nExit.\n" );
        	break;
        }
    }
        
/*	wr_buf[0] = 0x58;
	wr_buf[1] = 1;
	wr_buf[2] = 0;
	wr_buf[3] = 0;
	
	i2c_flag = USBIO_StreamI2C(0, 4, wr_buf, 0, rd_buf);

	wr_buf[0] = 0x58;
	wr_buf[1] = 0;
	
	i2c_flag = USBIO_StreamI2C(0, 2, wr_buf, 128, rd_buf);
*/
	
	printf( "*** USBIO_CloseDevice: 0 \n" );
	USBIO_CloseDevice( 0 );
}


//дCP2512�Ĵ�������������Ϊ�Ĵ�����ַ����Ҫд�������
unsigned char write_2512_reg(unsigned char reg_addr, unsigned int reg_data)
{
	unsigned char wr_buf[3];

	wr_buf[0] = reg_addr<<1;
	wr_buf[1] = (unsigned char)((reg_data & 0xff00)>>8);
	wr_buf[2] = (unsigned char)(reg_data & 0xff);

	return USBIO_StreamSPI4(0, 0x80, 3, wr_buf);
}

//дCP2512�Ĵ�������������Ϊ�Ĵ�����ʼ��ַ����ȡ�ļĴ������������ݻ�������ַ
unsigned char read_2512_reg(unsigned char reg_addr, unsigned char rd_num, unsigned int *reg_buffer)
{
	unsigned char flag;
	unsigned char wr_buf[256];
	unsigned int i;

	wr_buf[0] = reg_addr*2 + 1;
	wr_buf[1] = 0;
	wr_buf[2] = 0;

	flag = USBIO_StreamSPI4(0, 0x80, rd_num*2+1, wr_buf);
	
	for (i = 0; i < (unsigned int)rd_num; i++)
	{
		reg_buffer[i] = (unsigned int)(wr_buf[2*i]&1) << 15;
		reg_buffer[i] += (unsigned int)(wr_buf[2*i+1]) << 7;
		reg_buffer[i] += (unsigned int)(wr_buf[2*i+2] & 0xfe) >> 1;
	}

	return flag;
}

//i2c �ӿ�SCLKʱ��Ƶ�����ú���
unsigned char set_sclk_freq(unsigned int sclk)
{
	return USBIO_SetStream(0, sclk);
}